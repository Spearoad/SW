package com.example.shortformdetector  // ← 패키지명은 프로젝트에 맞게

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ShortFormDetectorService : AccessibilityService() {

    companion object {
        private const val TAG = "ShortFormDetector"

        private const val PKG_YOUTUBE = "com.google.android.youtube"
        private const val PKG_INSTAGRAM = "com.instagram.android"
    }
    // 유튜브에서 Shorts 탭이 눌렸는지 상태
    private var youtubeShortsMode: Boolean = false

    // 현재 어떤 숏폼 화면인지
    private enum class ShortFormType {
        NONE, YOUTUBE_SHORTS, INSTAGRAM_REELS
    }

    private var lastType: ShortFormType = ShortFormType.NONE

    // 인스타에서 Reels 탭이 눌렸는지 상태
    private var instagramReelsMode: Boolean = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        val type = event.eventType

        // -----------------------------
        // 1) 인스타: 탭 클릭으로 Reels 모드 on/off
        // -----------------------------
        if (pkg == PKG_INSTAGRAM && type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val node = event.source
            val label = buildString {
                append(node?.text?.toString() ?: "")
                append(" ")
                append(node?.contentDescription?.toString() ?: "")
                append(" ")
                append(node?.viewIdResourceName?.toString() ?: "")
            }.lowercase()
            if (label.contains("shorts") || label.contains("쇼츠")) {
                youtubeShortsMode = true
                // (이 로그는 한 번만 깔끔히 보이게 하고 싶으면 아래 로그는 지워도 됨)
                Log.d(TAG, "YouTube Shorts 탭 클릭 → Shorts 모드 ON")
            }

            // 다른 탭 클릭 → OFF (Home/Subscriptions/You 등)
            if (label.contains("home") || label.contains("홈") ||
                label.contains("subscriptions") || label.contains("구독") ||
                label.contains("you") || label.contains("나") ||
                label.contains("library") || label.contains("보관함")
            ) {
                youtubeShortsMode = false
                Log.d(TAG, "YouTube 다른 탭 클릭 → Shorts 모드 OFF")
            }


            val lower = label.lowercase()

            // Reels / 릴스 탭 클릭 → Reels 모드 ON
            if (lower.contains("reels") || label.contains("릴스")) {
                instagramReelsMode = true
                Log.d(TAG, "Instagram Reels 탭 클릭 → Reels 모드 ON")
            }

            // Home / Search / Profile 등 탭 클릭 → Reels 모드 OFF
            if (lower.contains("home") ||
                lower.contains("search") ||
                lower.contains("profile") ||
                label.contains("홈") ||
                label.contains("검색") ||
                label.contains("프로필")
            ) {
                instagramReelsMode = false
                Log.d(TAG, "Instagram 다른 탭 클릭 → Reels 모드 OFF")
            }
        }

        // 우리가 감지하려는 앱이 아니면 무시
        if (pkg != PKG_YOUTUBE && pkg != PKG_INSTAGRAM) return

        // 화면 내용이 바뀌었을 때만 숏폼 여부 판정
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_VIEW_CLICKED
        ) {
            return
        }

        val root = rootInActiveWindow ?: return

        // -----------------------------
        // 2) 앱별 숏폼 타입 계산
        // -----------------------------
        val newType: ShortFormType = when (pkg) {
            PKG_YOUTUBE -> {
                if (youtubeShortsMode || isYouTubeShorts(root)) ShortFormType.YOUTUBE_SHORTS
                else ShortFormType.NONE
            }
            PKG_INSTAGRAM -> {
                if (instagramReelsMode) ShortFormType.INSTAGRAM_REELS
                else ShortFormType.NONE
            }
            else -> ShortFormType.NONE
        }

        // -----------------------------
        // 3) 상태가 바뀔 때만 로그 출력
        // -----------------------------
        if (newType != lastType) {
            when {
                lastType == ShortFormType.NONE && newType == ShortFormType.YOUTUBE_SHORTS ->
                    Log.d(TAG, "🎯 숏폼 진입: YOUTUBE_SHORTS")

                lastType == ShortFormType.NONE && newType == ShortFormType.INSTAGRAM_REELS ->
                    Log.d(TAG, "🎯 숏폼 진입: INSTAGRAM_REELS")

                lastType != ShortFormType.NONE && newType == ShortFormType.NONE ->
                    Log.d(TAG, "ℹ 숏폼 화면 종료")

                lastType == ShortFormType.YOUTUBE_SHORTS && newType == ShortFormType.INSTAGRAM_REELS ->
                    Log.d(TAG, "ℹ YOUTUBE_SHORTS → INSTAGRAM_REELS 전환")

                lastType == ShortFormType.INSTAGRAM_REELS && newType == ShortFormType.YOUTUBE_SHORTS ->
                    Log.d(TAG, "ℹ INSTAGRAM_REELS → YOUTUBE_SHORTS 전환")
            }
            lastType = newType
        }
    }

    override fun onInterrupt() {
        // nothing
    }

    // =======================
    //   YouTube Shorts 감지
    // =======================
    private fun isYouTubeShorts(root: AccessibilityNodeInfo): Boolean {
        var shortsLabelNonNav = false
        var reelHint = false

        var hasLike = false
        var hasComment = false
        var hasShare = false
        var hasRemix = false
        var hasDislike = false

        val queue: ArrayDeque<AccessibilityNodeInfo> = ArrayDeque()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()

            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val id = node.viewIdResourceName?.toString() ?: ""
            val label = (text + " " + desc).lowercase()
            val idLower = id.lowercase()

            // Shorts/쇼츠 라벨 (하단 네비게이션은 제외)
            if ((label.contains("shorts") || label.contains("쇼츠")) && !isYouTubeBottomNavCluster(node)) {
                shortsLabelNonNav = true
            }

            // Shorts 화면에서 자주 보이는 힌트(id에 reel/shorts가 섞이는 경우가 많음)
            if (idLower.contains("reel") || idLower.contains("shorts")) {
                reelHint = true
            }

            // 쇼츠의 세로 액션 버튼들(언어 대응)
            if (label.contains("좋아요") || label.startsWith("like")) hasLike = true
            if (label.contains("싫어요") || label.contains("dislike")) hasDislike = true
            if (label.contains("댓글") || label.contains("comment")) hasComment = true
            if (label.contains("공유") || label.contains("share")) hasShare = true
            if (label.contains("리믹스") || label.contains("remix")) hasRemix = true

            // 충분히 모이면 조기 종료(성능)
            val actionCount = listOf(hasLike, hasDislike, hasComment, hasShare, hasRemix).count { it }
            if (reelHint && actionCount >= 2) return true

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(queue::add)
            }
        }

        val actionCount = listOf(hasLike, hasDislike, hasComment, hasShare, hasRemix).count { it }

        // ✅ 최종 판정: "쇼츠 플레이어 느낌"이 나야만 true
        return (reelHint && actionCount >= 2) || (shortsLabelNonNav && reelHint && actionCount >= 1)
    }



    private fun isYouTubeBottomNavCluster(node: AccessibilityNodeInfo): Boolean {
        val parent = node.parent ?: return false

        var hasHome = false
        var hasSubs = false
        var hasYou = false
        var hasCreate = false

        for (i in 0 until parent.childCount) {
            val sib = parent.getChild(i) ?: continue
            val t = sib.text?.toString() ?: ""
            val d = sib.contentDescription?.toString() ?: ""
            val s = (t + " " + d).lowercase()

            if (s.contains("home") || s.contains("홈")) hasHome = true
            if (s.contains("subscriptions") || s.contains("구독")) hasSubs = true
            if (s == "you" || s.contains("you") || s.contains("나")) hasYou = true
            if (s.contains("create") || s.contains("만들기")) hasCreate = true
        }

        // 하단 탭들은 보통 같이 묶여 있음
        return (hasHome && hasSubs) || (hasHome && hasYou) || (hasCreate && (hasHome || hasSubs || hasYou))
    }
        

}
