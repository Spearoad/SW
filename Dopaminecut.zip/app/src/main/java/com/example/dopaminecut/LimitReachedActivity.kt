package com.example.dopaminecut

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.dopaminecut.ui.theme.DopaminecutTheme
import kotlin.math.max

class LimitReachedActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REASON = "reason"
        const val EXTRA_MODE = "mode" // "COUNT" or "TIME"
        const val EXTRA_COUNT = "count"
        const val EXTRA_LIMIT_COUNT = "limitCount"
        const val EXTRA_USED_MS = "usedMs"
        const val EXTRA_LIMIT_TIME_MIN = "limitTimeMin"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val reason = intent.getStringExtra(EXTRA_REASON) ?: "제한 도달"
        val mode = intent.getStringExtra(EXTRA_MODE) ?: AppPrefs.LimitMode.COUNT.name
        val count = intent.getIntExtra(EXTRA_COUNT, 0)
        val limitCount = intent.getIntExtra(EXTRA_LIMIT_COUNT, 5)
        val usedMs = intent.getLongExtra(EXTRA_USED_MS, 0L)
        val limitTimeMin = intent.getIntExtra(EXTRA_LIMIT_TIME_MIN, 15)

        setContent {
            DopaminecutTheme {
                Surface(Modifier.fillMaxSize()) {
                    LimitReachedScreen(
                        reason = reason,
                        mode = mode,
                        count = count,
                        limitCount = limitCount,
                        usedMs = usedMs,
                        limitTimeMin = limitTimeMin,
                        onClose = { finish() },
                        onOpenApp = {
                            startActivity(Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            })
                            finish()
                        },
                        onOpenAccessibility = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    )
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = max(0L, ms / 1000L)
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}

@Composable
private fun LimitReachedScreen(
    reason: String,
    mode: String,
    count: Int,
    limitCount: Int,
    usedMs: Long,
    limitTimeMin: Int,
    onClose: () -> Unit,
    onOpenApp: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    val modeLabel = if (mode == AppPrefs.LimitMode.TIME.name) "시간 제한" else "영상 개수 제한"

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(6.dp))

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.dopaminecut_logo),
                            contentDescription = null,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("제한 도달", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(modeLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Text(reason, style = MaterialTheme.typography.bodyMedium)

                    Divider()

                    Text("오늘 영상: $count / $limitCount", fontWeight = FontWeight.SemiBold)
                    Text("오늘 시간: ${formatMs(usedMs)} / ${limitTimeMin}분", fontWeight = FontWeight.SemiBold)

                    Text(
                        "YouTube Shorts 사용을 멈추고 홈으로 이동했어요.\n" +
                                "설정은 앱에서 바꿀 수 있어요.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Button(onClick = onOpenApp, modifier = Modifier.fillMaxWidth()) {
                Text("DopamineCut로 이동(설정/현황)")
            }

            OutlinedButton(onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth()) {
                Text("접근성 설정 열기")
            }

            TextButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
                Text("닫기")
            }

            Spacer(Modifier.weight(1f))
        }
    }
}
