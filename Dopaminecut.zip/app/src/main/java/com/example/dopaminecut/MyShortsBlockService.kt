package com.example.dopaminecut

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyShortsBlockService : AccessibilityService() {

    private val TARGET_SHORTS_LIMIT = 5
    private var currentShortsCount = 0
    private val viewedShortsTitles = mutableSetOf<String>()

    private var lastProcessTime = 0L
    private val THROTTLE_INTERVAL = 300L

    // 주기적 확인을 위한 Handler 와 Runnable
    private lateinit var handler: Handler
    private lateinit var checkRunnable: Runnable
    private val CHECK_INTERVAL = 300L // 0.3초마다 화면을 주기적으로 스캔

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler = Handler(Looper.getMainLooper())
        checkRunnable = Runnable {
            Log.d("DopamineCut", "스캔 중")
            processScreenContent()
            handler.postDelayed(checkRunnable, CHECK_INTERVAL)
        }
        handler.post(checkRunnable)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName == "com.google.android.youtube") {
            processScreenContent()
        }
    }

    private fun processScreenContent() {
        if (System.currentTimeMillis() - lastProcessTime < THROTTLE_INTERVAL) return
        lastProcessTime = System.currentTimeMillis()

        val rootNode = rootInActiveWindow ?: return

        if (!isShortsFeed(rootNode)) {
            return
        }

        val viewGroupTexts = mutableListOf<String>()
        collectViewGroups(rootNode, viewGroupTexts)

        if (isAdShort(viewGroupTexts)) {
            Log.d("DopamineCut", "광고 식별됨 카운트안함")
            lastProcessTime = 0L
            return
        }

        val title = findTitleByStrategy(viewGroupTexts)

        if (title.isNotEmpty() && !viewedShortsTitles.contains(title)) {
            processNewShorts(title)
        }
    }

    private fun isShortsFeed(rootNode: AccessibilityNodeInfo): Boolean {
        val characteristicDescriptions = setOf(
            "Dislike this video",
            "View comments",
            "Share this video"
        )
        var foundCount = 0

        fun findNode(node: AccessibilityNodeInfo?) {
            if (node == null || foundCount >= 2) return
            val desc = node.contentDescription?.toString()
            if (desc != null && characteristicDescriptions.contains(desc)) {
                foundCount++
            }
            for (i in 0 until node.childCount) {
                if (foundCount < 2) {
                    findNode(node.getChild(i))
                }
            }
        }
        findNode(rootNode)
        return foundCount >= 2
    }

    private fun collectViewGroups(node: AccessibilityNodeInfo?, list: MutableList<String>) {
        if (node == null || !node.isVisibleToUser) return

        if (node.className == "android.view.ViewGroup") {
            val content = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
            list.add(content)
        }

        for (i in 0 until node.childCount) {
            collectViewGroups(node.getChild(i), list)
        }
    }

    private fun isAdShort(list: List<String>): Boolean {
        return list.any { it.equals("Ad", ignoreCase = true) || it.equals("광고", ignoreCase = true) }
    }

    private fun findTitleByStrategy(list: List<String>): String {
        val size = list.size
        if (size < 4) return ""

        var candidate = list[size - 4]

        // 'Earns commission' 케이스를 먼저 처리
        if (candidate.contains("Earns commission")) {
            if (size >= 7) {
                Log.w("DopamineCut", "'Earns commission' 감지, 7번째 항목으로 변경")
                return list[size - 7] // 7번째 항목을 반환하고 즉시 종료
            } else {
                return "" // 7번째 항목이 없으면 실패
            }
        }

        return candidate
    }

    private fun processNewShorts(title: String) {
        viewedShortsTitles.add(title)
        currentShortsCount++
        Log.e("DopamineCut", "[카운트] $currentShortsCount / $TARGET_SHORTS_LIMIT | 제목: $title")

        val remaining = TARGET_SHORTS_LIMIT - currentShortsCount
        if (remaining == (TARGET_SHORTS_LIMIT * 0.4).toInt()) {
            Log.w("DopamineCut", "잔여 쇼츠 40%")
        }

        if (remaining <= 0) {
            blockShorts()
        }
        lastProcessTime = 0L
    }

    private fun blockShorts() {
        Log.e("DopamineCut", "목표 도달! 뒤로가기 실행")
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    override fun onInterrupt() {
        if (::handler.isInitialized) {
            handler.removeCallbacks(checkRunnable)
        }
    }
}
