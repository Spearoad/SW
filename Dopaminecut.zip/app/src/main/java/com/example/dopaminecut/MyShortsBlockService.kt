package com.example.dopaminecut

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class MyShortsBlockService : AccessibilityService() {
    private var limitMode: AppPrefs.LimitMode = AppPrefs.LimitMode.COUNT
    private var limitCount = 5
    private var countToday = 0
    private var limitTimeMin = 15
    private var timeUsedMsBase = 0L
    private var inShorts = false
    private var sessionStartMs = 0L
    private var lastFlushMs = 0L
    private val FLUSH_EVERY_MS = 3000L
    private val handler = Handler(Looper.getMainLooper())
    private val DEBOUNCE_MS = 90L
    private var lastProcessTime = 0L
    private val THROTTLE_INTERVAL = 80L
    private var lastBlockAt = 0L
    private val BLOCK_COOLDOWN_MS = 2000L
    private val CHECK_INTERVAL = 300L

    private val viewedShortsTitles = mutableSetOf<String>()
    private val reusableViewGroupTexts = mutableListOf<String>()
    private val reusableButtonTexts = mutableListOf<String>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val periodicScanRunnable = object : Runnable {
        override fun run() {
            if (inShorts) {
                processScreenContent()
                handler.postDelayed(this, CHECK_INTERVAL)
            }
        }
    }

    private val tickerRunnable = object : Runnable {
        override fun run() {
            if (inShorts) {
                tickTimeOnly()
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private val screenStateCheckRunnable = Runnable { checkScreenState() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("DopamineCut", "Service connected")
        scope.launch { AppPrefs.initTodayIfNeeded(applicationContext) }
        scope.launch { AppPrefs.limitModeFlow(applicationContext).collectLatest { limitMode = it } }
        scope.launch { AppPrefs.limitCountFlow(applicationContext).collectLatest { limitCount = it } }
        scope.launch { AppPrefs.countFlow(applicationContext).collectLatest { countToday = it } }
        scope.launch { AppPrefs.limitTimeMinFlow(applicationContext).collectLatest { limitTimeMin = it } }
        scope.launch { AppPrefs.timeUsedMsFlow(applicationContext).collectLatest { timeUsedMsBase = it } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.google.android.youtube") return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_START,
            AccessibilityEvent.TYPE_TOUCH_INTERACTION_END -> {
                handler.removeCallbacks(screenStateCheckRunnable)
                handler.postDelayed(screenStateCheckRunnable, DEBOUNCE_MS)
            }
        }
    }

    private fun checkScreenState() {
        val root = rootInActiveWindow ?: return
        val isShortsNow = isShortsFeedLikely(root)
        updateShortsSessionState(isShortsNow)

        if (isShortsNow) {
            processScreenContent()
        }
    }

    private fun processScreenContent() {
        val now = System.currentTimeMillis()
        if (now - lastProcessTime < THROTTLE_INTERVAL) return
        lastProcessTime = now

        val root = rootInActiveWindow ?: return

        if (limitMode == AppPrefs.LimitMode.TIME && isTimeExceeded(now)) {
            blockShorts("시간 제한 초과")
            return
        }

        // ViewGroup과 Button 텍스트를 별도로 수집
        reusableViewGroupTexts.clear()
        collectViewGroups(root, reusableViewGroupTexts)
        reusableButtonTexts.clear()
        collectButtonTexts(root, reusableButtonTexts)

        if (isAd(reusableViewGroupTexts)) {
            Log.d("DopamineCut", "광고 식별됨 카운트안함")
            lastProcessTime = 0L
            return
        }

        val title = findTitleByStrategy(reusableViewGroupTexts, reusableButtonTexts)

        if (title.isNotEmpty() && !viewedShortsTitles.contains(title)) {
            processNewShorts(title)
        }
    }

    private fun processNewShorts(title: String) {
        viewedShortsTitles.add(title)

        scope.launch { AppPrefs.incrementCount(applicationContext) }
        val next = countToday + 1
        Log.e("DopamineCut", "[카운트] $next / $limitCount | 제목: $title")

        if (limitMode == AppPrefs.LimitMode.COUNT && next >= limitCount) {
            blockShorts("개수 제한 초과")
        }

        lastProcessTime = 0L
    }

    private fun updateShortsSessionState(isShortsNow: Boolean) {
        val now = System.currentTimeMillis()
        if (isShortsNow && !inShorts) { // 숏폼 세션 시작
            inShorts = true
            sessionStartMs = now
            lastFlushMs = now
            handler.removeCallbacks(tickerRunnable)
            handler.postDelayed(tickerRunnable, 1000L)
            handler.removeCallbacks(periodicScanRunnable)
            handler.post(periodicScanRunnable)
            return
        }
        if (!isShortsNow && inShorts) { // 숏폼 세션 종료
            flushTime(now, force = true)
            inShorts = false
            sessionStartMs = 0L
            handler.removeCallbacks(tickerRunnable)
            handler.removeCallbacks(periodicScanRunnable)
        }
    }

    private fun tickTimeOnly() {
        val now = System.currentTimeMillis()
        if (!inShorts) return
        flushTime(now, force = false)
        if (limitMode == AppPrefs.LimitMode.TIME && isTimeExceeded(now)) {
            blockShorts("시간 제한 초과")
        }
    }

    private fun flushTime(now: Long, force: Boolean) {
        if (!inShorts || sessionStartMs == 0L) return
        val elapsed = (now - sessionStartMs).coerceAtLeast(0L)
        val total = timeUsedMsBase + elapsed
        if (!force && now - lastFlushMs < FLUSH_EVERY_MS) return
        lastFlushMs = now
        scope.launch { AppPrefs.setTimeUsedMs(applicationContext, total) }
        timeUsedMsBase = total
        sessionStartMs = now
    }

    private fun currentTimeUsedMs(now: Long): Long {
        return if (inShorts && sessionStartMs != 0L) {
            timeUsedMsBase + (now - sessionStartMs).coerceAtLeast(0L)
        } else {
            timeUsedMsBase
        }
    }

    private fun isTimeExceeded(now: Long): Boolean {
        val limitMs = limitTimeMin.toLong() * 60_000L
        return currentTimeUsedMs(now) >= limitMs
    } 

    private fun blockShorts(reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockAt < BLOCK_COOLDOWN_MS) return
        lastBlockAt = now
        flushTime(now, force = true)
        Log.e("DopamineCut", "차단: $reason → 홈 이동")
        performGlobalAction(GLOBAL_ACTION_HOME)
        scope.launch { AppPrefs.markLimitReached(applicationContext) }

        val intent = Intent(this, LimitReachedActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(LimitReachedActivity.EXTRA_REASON, reason)
            putExtra(LimitReachedActivity.EXTRA_MODE, limitMode.name)
            putExtra(LimitReachedActivity.EXTRA_COUNT, countToday)
            putExtra(LimitReachedActivity.EXTRA_LIMIT_COUNT, limitCount)
            putExtra(LimitReachedActivity.EXTRA_USED_MS, currentTimeUsedMs(now))
            putExtra(LimitReachedActivity.EXTRA_LIMIT_TIME_MIN, limitTimeMin)
        }
        handler.postDelayed({ startActivity(intent) }, 350L)
    }

    private fun isShortsFeedLikely(root: AccessibilityNodeInfo): Boolean {
        val patterns = listOf("댓글", "comments", "공유", "share", "좋아요", "like", "싫어요", "dislike", "리믹스", "remix")
        var hit = 0
        fun dfs(n: AccessibilityNodeInfo?) {
            if (n == null || hit >= 3) return
            val desc = n.contentDescription?.toString()?.lowercase()
            if (!desc.isNullOrBlank() && patterns.any { desc.contains(it) }) hit++
            for (i in 0 until n.childCount) dfs(n.getChild(i))
        }
        dfs(root)
        return hit >= 2
    }

    private fun collectViewGroups(node: AccessibilityNodeInfo?, list: MutableList<String>) {
        if (node == null || !node.isVisibleToUser) return
        if (node.className == "android.view.ViewGroup") {
            val content = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
            list.add(content)
        }
        for (i in 0 until node.childCount) {
            collectViewGroups(node.getChild(i), list)
        }
    }

    // Class: android.widget.Button 텍스트만 수집하는 함수 추가
    private fun collectButtonTexts(node: AccessibilityNodeInfo?, list: MutableList<String>) {
        if (node == null || !node.isVisibleToUser) return
        if (node.className == "android.widget.Button") {
            val content = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
            list.add(content)
        }
        for (i in 0 until node.childCount) {
            collectButtonTexts(node.getChild(i), list)
        }
    }

    private fun isAd(list: List<String>): Boolean {
        return list.any { it.equals("Ad", ignoreCase = true) || it.equals("광고", ignoreCase = true) }
    }

    private fun findTitleByStrategy(viewGroupList: List<String>, buttonList: List<String>): String {
        val viewGroupSize = viewGroupList.size
        val buttonSize = buttonList.size

        // 숏폼 포멧 1
        if (buttonSize >= 9 && viewGroupSize >= 5 && buttonList[buttonSize - 9].contains("·")) {
            Log.w("DopamineCut", "특수 음악 정보(9번째 버튼) 감지, 5번째 ViewGroup 항목으로 변경")
            return viewGroupList[viewGroupSize - 5]
        }

        // 숏폼 포맷 2
        if (viewGroupSize >= 8 && viewGroupList[viewGroupSize - 5].contains("Earns commission")) {
            Log.w("DopamineCut", "'Earns commission' (5번째 ViewGroup) 감지, 8번째 ViewGroup 항목으로 변경")
            return viewGroupList[viewGroupSize - 8]
        }

        // 숏폼 포맷 3
        if (viewGroupSize < 4) return ""
        val candidate = viewGroupList[viewGroupSize - 4]

        // 숏폼 포맷 4
        if (candidate.contains("·")) {
            if (viewGroupSize >= 5) {
                Log.w("DopamineCut", "음악 정보(4번째 ViewGroup) 감지, 5번째 ViewGroup 항목으로 변경")
                return viewGroupList[viewGroupSize - 5]
            } else {
                return ""
            }
        }

        return candidate
    }

    override fun onInterrupt() {
        handler.removeCallbacks(screenStateCheckRunnable)
        handler.removeCallbacks(periodicScanRunnable)
        handler.removeCallbacks(tickerRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(screenStateCheckRunnable)
        handler.removeCallbacks(periodicScanRunnable)
        handler.removeCallbacks(tickerRunnable)
        scope.cancel()
    }
}
