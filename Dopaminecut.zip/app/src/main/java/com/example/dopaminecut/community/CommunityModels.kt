package com.example.dopaminecut.community

data class Post(
    val id: String = "",
    val authorUid: String = "",
    val authorName: String = "익명",
    val title: String = "",
    val content: String = "",
    val createdAt: Long = 0L,
    val likeCount: Int = 0,
    val commentCount: Int = 0
)

data class Comment(
    val id: String = "",
    val authorUid: String = "",
    val authorName: String = "익명",
    val content: String = "",
    val createdAt: Long = 0L
)
