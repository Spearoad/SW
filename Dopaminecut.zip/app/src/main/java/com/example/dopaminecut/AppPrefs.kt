package com.example.dopaminecut

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val DATASTORE_NAME = "dopaminecut_prefs"
private val Context.dataStore by preferencesDataStore(name = DATASTORE_NAME)

object AppPrefs {

    enum class LimitMode { COUNT, TIME }

    private val KEY_DATE = stringPreferencesKey("date") // yyyy-MM-dd

    private val KEY_MODE = stringPreferencesKey("mode")
    private val KEY_COUNT = intPreferencesKey("count")
    private val KEY_LIMIT_COUNT = intPreferencesKey("limit_count")

    private val KEY_TIME_USED_MS = longPreferencesKey("time_used_ms")
    private val KEY_LIMIT_TIME_MIN = intPreferencesKey("limit_time_min")

    // 오늘 “차단 발생(한도 도달)” 여부 (실패 플래그)
    private val KEY_LIMIT_REACHED = booleanPreferencesKey("limit_reached")

    // 커뮤니티 닉네임(기본 닉)
    private val KEY_NICKNAME = stringPreferencesKey("nickname")

    // 보상/칭호
    private val KEY_STREAK = intPreferencesKey("streak")          // 연속 성공(현재)
    private val KEY_BEST_STREAK = intPreferencesKey("best_streak")// 최고 연속
    private val KEY_POINTS = intPreferencesKey("points")
    private val KEY_TITLE = stringPreferencesKey("title")         // 현재 보유 칭호(최고 기준)
    private val KEY_LAST_REWARD_MSG = stringPreferencesKey("last_reward_msg") // 홈에서 1회 알림용

    private fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun titleForBestStreak(best: Int): String = when {
        best >= 30 -> "God"
        best >= 14 -> "아직 버텨? "
        best >= 7  -> "절제의 달인"
        best >= 3  -> "도파민 커터"
        best >= 1  -> "첫 절제"
        else -> ""
    }

    fun decorateNickname(base: String, title: String): String {
        val b = base.ifBlank { "익명" }
        return if (title.isBlank()) b else "[$title] $b"
    }

    // ---------- Flows ----------
    fun limitModeFlow(context: Context): Flow<LimitMode> =
        context.dataStore.data.map {
            runCatching { LimitMode.valueOf(it[KEY_MODE] ?: LimitMode.COUNT.name) }
                .getOrDefault(LimitMode.COUNT)
        }

    fun countFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_COUNT] ?: 0 }

    fun limitCountFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_LIMIT_COUNT] ?: 5 }

    fun timeUsedMsFlow(context: Context): Flow<Long> =
        context.dataStore.data.map { it[KEY_TIME_USED_MS] ?: 0L }

    fun limitTimeMinFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_LIMIT_TIME_MIN] ?: 15 }

    fun nicknameFlow(context: Context): Flow<String> =
        context.dataStore.data.map { it[KEY_NICKNAME] ?: "익명" }

    fun streakFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_STREAK] ?: 0 }

    fun bestStreakFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_BEST_STREAK] ?: 0 }

    fun pointsFlow(context: Context): Flow<Int> =
        context.dataStore.data.map { it[KEY_POINTS] ?: 0 }

    fun titleFlow(context: Context): Flow<String> =
        context.dataStore.data.map { it[KEY_TITLE] ?: "" }

    fun lastRewardMsgFlow(context: Context): Flow<String> =
        context.dataStore.data.map { it[KEY_LAST_REWARD_MSG] ?: "" }

    // ---------- Setters ----------
    suspend fun setLimitMode(context: Context, mode: LimitMode) {
        context.dataStore.edit { it[KEY_MODE] = mode.name }
    }

    suspend fun setLimitCount(context: Context, limit: Int) {
        context.dataStore.edit { it[KEY_LIMIT_COUNT] = limit.coerceIn(1, 999) }
    }

    suspend fun setLimitTimeMin(context: Context, min: Int) {
        context.dataStore.edit { it[KEY_LIMIT_TIME_MIN] = min.coerceAtLeast(1) }
    }

    suspend fun setNickname(context: Context, nickname: String) {
        context.dataStore.edit { it[KEY_NICKNAME] = nickname.trim().take(12).ifBlank { "익명" } }
    }

    suspend fun setCount(context: Context, value: Int) {
        context.dataStore.edit { it[KEY_COUNT] = value.coerceAtLeast(0) }
    }

    suspend fun setTimeUsedMs(context: Context, value: Long) {
        context.dataStore.edit { it[KEY_TIME_USED_MS] = value.coerceAtLeast(0L) }
    }

    suspend fun markLimitReached(context: Context) {
        context.dataStore.edit { it[KEY_LIMIT_REACHED] = true }
    }

    suspend fun clearLastRewardMsg(context: Context) {
        context.dataStore.edit { it[KEY_LAST_REWARD_MSG] = "" }
    }

    // ---------- Day rollover + reward ----------
    /**
     * 날짜가 바뀌면 “어제” 기록으로 목표 달성 여부를 평가하고
     * 성공이면 streak/points/title을 업데이트하고, 오늘 기록을 초기화합니다.
     *
     * ⚠️ 앱을 켜거나(또는 접근성 서비스가 살아있을 때) 실행될 때만 평가됩니다.
     */
    suspend fun initTodayIfNeeded(context: Context) {
        val prefs = context.dataStore.data.first()
        val savedDate = prefs[KEY_DATE].orEmpty()
        val today = todayKey()

        if (savedDate.isBlank()) {
            context.dataStore.edit {
                it[KEY_DATE] = today
                it[KEY_MODE] = it[KEY_MODE] ?: LimitMode.COUNT.name
                it[KEY_LIMIT_COUNT] = it[KEY_LIMIT_COUNT] ?: 5
                it[KEY_LIMIT_TIME_MIN] = it[KEY_LIMIT_TIME_MIN] ?: 15
                it[KEY_NICKNAME] = it[KEY_NICKNAME] ?: "익명"
                it[KEY_LIMIT_REACHED] = false
            }
            return
        }

        if (savedDate == today) return

        // ---- 어제 평가 ----
        val mode = runCatching { LimitMode.valueOf(prefs[KEY_MODE] ?: LimitMode.COUNT.name) }
            .getOrDefault(LimitMode.COUNT)
        val count = prefs[KEY_COUNT] ?: 0
        val limitCount = prefs[KEY_LIMIT_COUNT] ?: 5
        val timeUsed = prefs[KEY_TIME_USED_MS] ?: 0L
        val limitTimeMin = prefs[KEY_LIMIT_TIME_MIN] ?: 15
        val limitReached = prefs[KEY_LIMIT_REACHED] ?: false

        val withinGoal = when (mode) {
            LimitMode.COUNT -> count <= limitCount
            LimitMode.TIME -> timeUsed <= (limitTimeMin.coerceAtLeast(1) * 60_000L)
        }

        val success = (!limitReached) && withinGoal

        val prevStreak = prefs[KEY_STREAK] ?: 0
        val prevBest = prefs[KEY_BEST_STREAK] ?: 0
        val prevPoints = prefs[KEY_POINTS] ?: 0

        val newStreak = if (success) prevStreak + 1 else 0
        val newBest = max(prevBest, newStreak)
        val newTitle = titleForBestStreak(newBest)
        val newPoints = prevPoints + if (success) 10 else 0

        val titleText = if (newTitle.isBlank()) "없음" else newTitle

        val rewardMsg = if (success) {
            "🎉 목표 달성! 연속 ${newStreak}일 (최고 ${newBest}일) · 칭호: $titleText"
        } else {
            ""
        }


        // ---- 오늘로 초기화 ----
        context.dataStore.edit { p ->
            p[KEY_DATE] = today
            p[KEY_COUNT] = 0
            p[KEY_TIME_USED_MS] = 0L
            p[KEY_LIMIT_REACHED] = false

            p[KEY_STREAK] = newStreak
            p[KEY_BEST_STREAK] = newBest
            p[KEY_TITLE] = newTitle
            p[KEY_POINTS] = newPoints
            p[KEY_LAST_REWARD_MSG] = rewardMsg
        }
    }

    suspend fun resetToday(context: Context) {
        context.dataStore.edit {
            it[KEY_COUNT] = 0
            it[KEY_TIME_USED_MS] = 0L
            it[KEY_LIMIT_REACHED] = false
        }
    }
    suspend fun incrementCount(context: Context, delta: Int = 1) {
        context.dataStore.edit { prefs ->
            val cur = prefs[KEY_COUNT] ?: 0
            prefs[KEY_COUNT] = (cur + delta).coerceAtLeast(0)
        }
    }

    suspend fun addTimeUsedMs(context: Context, deltaMs: Long) {
        if (deltaMs <= 0L) return
        context.dataStore.edit { prefs ->
            val cur = prefs[KEY_TIME_USED_MS] ?: 0L
            prefs[KEY_TIME_USED_MS] = (cur + deltaMs).coerceAtLeast(0L)
        }
    }

}
