@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.dopaminecut.community

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.dopaminecut.AppPrefs
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun ts(ms: Long): String {
    if (ms <= 0L) return ""
    val sdf = SimpleDateFormat("MM/dd HH:mm", Locale.KOREA)
    return sdf.format(Date(ms))
}

sealed class CommunityRoute {
    data object List : CommunityRoute()
    data object Write : CommunityRoute()
    data class Detail(val post: Post) : CommunityRoute()
}

@Composable
fun CommunityHost(repo: CommunityRepository) {
    // ✅ rememberSaveable 쓰면 커스텀 타입 저장 문제로 튕길 수 있어서 remember 사용
    var route by remember { mutableStateOf<CommunityRoute>(CommunityRoute.List) }

    when (val r = route) {
        is CommunityRoute.List -> CommunityListScreen(
            repo = repo,
            onOpenPost = { route = CommunityRoute.Detail(it) },
            onWrite = { route = CommunityRoute.Write }
        )

        is CommunityRoute.Write -> WritePostScreen(
            repo = repo,
            onDone = { route = CommunityRoute.List },
            onBack = { route = CommunityRoute.List }
        )

        is CommunityRoute.Detail -> PostDetailScreen(
            repo = repo,
            post = r.post,
            onBack = { route = CommunityRoute.List }
        )
    }
}

@Composable
private fun CommunityListScreen(
    repo: CommunityRepository,
    onOpenPost: (Post) -> Unit,
    onWrite: () -> Unit
) {
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val reg: ListenerRegistration = repo.postsQuery().addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.message
                return@addSnapshotListener
            }
            posts = snap?.documents.orEmpty().map { d ->
                Post(
                    id = d.id,
                    authorUid = d.getString("authorUid") ?: "",
                    authorName = d.getString("authorName") ?: "익명",
                    title = d.getString("title") ?: "",
                    content = d.getString("content") ?: "",
                    createdAt = d.getLong("createdAt") ?: 0L,
                    likeCount = (d.getLong("likeCount") ?: 0L).toInt(),
                    commentCount = (d.getLong("commentCount") ?: 0L).toInt()
                )
            }
        }
        onDispose { reg.remove() }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("커뮤니티") }) },
        floatingActionButton = { FloatingActionButton(onClick = onWrite) { Text("+") } }
    ) { inner ->
        Column(
            Modifier
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (error != null) {
                Text("오류: $error", color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(posts, key = { it.id }) { p ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPost(p) }
                    ) {
                        Column(
                            Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(p.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                p.content.take(120),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("👍 ${p.likeCount}", style = MaterialTheme.typography.labelMedium)
                                Text("💬 ${p.commentCount}", style = MaterialTheme.typography.labelMedium)
                                Text(
                                    "${p.authorName} · ${ts(p.createdAt)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WritePostScreen(
    repo: CommunityRepository,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    // ✅ 앱에 저장된 닉네임/칭호(보상)
    val savedNick by AppPrefs.nicknameFlow(context).collectAsState(initial = "익명")
    val title by AppPrefs.titleFlow(context).collectAsState(initial = "")

    var nickname by remember { mutableStateOf("") } // 입력은 옵션(비우면 savedNick 사용)
    var titleText by remember { mutableStateOf("") }
    var contentText by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val effectiveBaseNick = nickname.trim().ifBlank { savedNick }
    val effectiveAuthor = AppPrefs.decorateNickname(effectiveBaseNick, title)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("글쓰기") },
                navigationIcon = { TextButton(onClick = onBack) { Text("뒤로") } },
                actions = {
                    TextButton(
                        enabled = !loading && titleText.isNotBlank() && contentText.isNotBlank(),
                        onClick = {
                            loading = true
                            error = null
                            scope.launch {
                                runCatching {
                                    repo.createPost(
                                        title = titleText.trim(),
                                        content = contentText.trim(),
                                        authorName = effectiveAuthor
                                    )
                                }.onFailure { error = it.message }

                                loading = false
                                if (error == null) onDone()
                            }
                        }
                    ) { Text("등록") }
                }
            )
        }
    ) { inner ->
        Column(
            Modifier
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (error != null) Text("오류: $error", color = MaterialTheme.colorScheme.error)
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            // ✅ 현재 적용될 닉네임 미리보기
            AssistChip(
                onClick = {},
                label = { Text("작성자: $effectiveAuthor") }
            )

            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it.take(12) },
                label = { Text("닉네임(선택, 비우면 '$savedNick')") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = titleText,
                onValueChange = { titleText = it.take(60) },
                label = { Text("제목") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = contentText,
                onValueChange = { contentText = it },
                label = { Text("내용") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 7
            )
        }
    }
}

@Composable
private fun PostDetailScreen(
    repo: CommunityRepository,
    post: Post,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    // ✅ 앱에 저장된 닉네임/칭호(보상)
    val savedNick by AppPrefs.nicknameFlow(context).collectAsState(initial = "익명")
    val title by AppPrefs.titleFlow(context).collectAsState(initial = "")

    var comments by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    var nickname by remember { mutableStateOf("") } // 댓글 작성 닉네임(선택)
    var commentText by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }

    val effectiveBaseNick = nickname.trim().ifBlank { savedNick }
    val effectiveAuthor = AppPrefs.decorateNickname(effectiveBaseNick, title)

    DisposableEffect(post.id) {
        val reg: ListenerRegistration = repo.commentsQuery(post.id).addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.message
                return@addSnapshotListener
            }
            comments = snap?.documents.orEmpty().map { d ->
                Comment(
                    id = d.id,
                    authorUid = d.getString("authorUid") ?: "",
                    authorName = d.getString("authorName") ?: "익명",
                    content = d.getString("content") ?: "",
                    createdAt = d.getLong("createdAt") ?: 0L
                )
            }
        }
        onDispose { reg.remove() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("게시글") },
                navigationIcon = { TextButton(onClick = onBack) { Text("뒤로") } },
                actions = {
                    TextButton(onClick = { scope.launch { repo.toggleLike(post.id) } }) { Text("좋아요") }
                }
            )
        }
    ) { inner ->
        Column(
            Modifier
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(post.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${post.authorName} · ${ts(post.createdAt)} · 👍 ${post.likeCount} · 💬 ${post.commentCount}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(post.content)
                }
            }

            if (error != null) Text("오류: $error", color = MaterialTheme.colorScheme.error)

            Text("댓글", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)

            LazyColumn(
                modifier = Modifier.weight(1f, fill = true),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(comments, key = { it.id }) { c ->
                    Card {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "${c.authorName} · ${ts(c.createdAt)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(c.content)
                        }
                    }
                }
            }

            if (sending) LinearProgressIndicator(Modifier.fillMaxWidth())

            AssistChip(
                onClick = {},
                label = { Text("댓글 작성자: $effectiveAuthor") }
            )

            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it.take(12) },
                label = { Text("닉네임(선택, 비우면 '$savedNick')") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    label = { Text("댓글 쓰기") },
                    modifier = Modifier.weight(1f)
                )
                Button(
                    enabled = !sending && commentText.isNotBlank(),
                    onClick = {
                        val msg = commentText.trim()
                        commentText = ""
                        sending = true
                        scope.launch {
                            runCatching { repo.addComment(post.id, msg, effectiveAuthor) }
                            sending = false
                        }
                    }
                ) { Text("등록") }
            }

            Spacer(Modifier.height(6.dp))
        }
    }
}
