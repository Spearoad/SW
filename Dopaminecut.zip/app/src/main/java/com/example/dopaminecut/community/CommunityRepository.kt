package com.example.dopaminecut.community

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await

class CommunityRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun me() = auth.currentUser

    suspend fun ensureSignedInAnonymously(): String {
        val current = me()
        if (current != null) return current.uid
        val res = auth.signInAnonymously().await()
        return res.user?.uid ?: error("Anonymous auth failed")
    }

    fun postsQuery() =
        db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)

    fun commentsQuery(postId: String) =
        db.collection("posts").document(postId)
            .collection("comments")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .limit(200)

    suspend fun createPost(title: String, content: String, authorName: String) {
        val uid = ensureSignedInAnonymously()
        val doc = db.collection("posts").document()
        doc.set(
            mapOf(
                "authorUid" to uid,
                "authorName" to authorName,
                "title" to title,
                "content" to content,
                "createdAt" to System.currentTimeMillis(),
                "likeCount" to 0,
                "commentCount" to 0
            )
        ).await()
    }

    suspend fun addComment(postId: String, content: String, authorName: String) {
        val uid = ensureSignedInAnonymously()
        val postRef = db.collection("posts").document(postId)
        val commentRef = postRef.collection("comments").document()

        db.runTransaction { tx ->
            tx.set(
                commentRef,
                mapOf(
                    "authorUid" to uid,
                    "authorName" to authorName,
                    "content" to content,
                    "createdAt" to System.currentTimeMillis()
                )
            )
            tx.update(postRef, "commentCount", FieldValue.increment(1))
        }.await()
    }

    suspend fun toggleLike(postId: String) {
        val uid = ensureSignedInAnonymously()
        val postRef = db.collection("posts").document(postId)
        val likeRef = postRef.collection("likes").document(uid)

        db.runTransaction { tx ->
            val likeSnap = tx.get(likeRef)
            if (likeSnap.exists()) {
                tx.delete(likeRef)
                tx.update(postRef, "likeCount", FieldValue.increment(-1))
            } else {
                tx.set(likeRef, mapOf("createdAt" to System.currentTimeMillis()))
                tx.update(postRef, "likeCount", FieldValue.increment(1))
            }
        }.await()
    }
}
