package com.example.dopaminecut

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.imePadding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.dopaminecut.community.CommunityHost
import com.example.dopaminecut.community.CommunityRepository
import com.example.dopaminecut.ui.theme.DopaminecutTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DopaminecutTheme {
                Surface(Modifier.fillMaxSize()) {
                    AppEntry()
                }
            }
        }
    }
}

private enum class EntryScreen { SPLASH, MAIN }
private enum class Tab { HOME, COMMUNITY }

@Composable
private fun AppEntry() {
    val context = LocalContext.current
    val repo = remember { CommunityRepository() }

    var screen by remember { mutableStateOf(EntryScreen.SPLASH) }
    var statusText by remember { mutableStateOf("준비 중…") }

    LaunchedEffect(Unit) {
        statusText = "데이터 불러오는 중…"
        AppPrefs.initTodayIfNeeded(context)

        statusText = "커뮤니티 연결 중…"
        runCatching { repo.ensureSignedInAnonymously() }

        delay(950)
        screen = EntryScreen.MAIN
    }

    AnimatedContent(targetState = screen, label = "entry") { s ->
        when (s) {
            EntryScreen.SPLASH -> SplashScreen(statusText = statusText)
            EntryScreen.MAIN -> MainTabs(repo = repo)
        }
    }
}

@Composable
private fun SplashScreen(statusText: String) {
    val alpha = remember { Animatable(0f) }
    val y = remember { Animatable(18f) }
    val scale = remember { Animatable(0.96f) }

    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(420, easing = LinearOutSlowInEasing)) }
        launch { y.animateTo(0f, tween(520, easing = FastOutSlowInEasing)) }
        launch { scale.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .graphicsLayer {
                    translationY = y.value
                    scaleX = scale.value
                    scaleY = scale.value
                }
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.dopaminecut_logo),
                contentDescription = "DopamineCut logo",
                modifier = Modifier.size(170.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "DopamineCut",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Shorts를 똑똑하게 끊어내기",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MainTabs(repo: CommunityRepository) {
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == Tab.HOME,
                    onClick = { tab = Tab.HOME },
                    label = { Text("홈") },
                    icon = { Text("🏠") }
                )
                NavigationBarItem(
                    selected = tab == Tab.COMMUNITY,
                    onClick = { tab = Tab.COMMUNITY },
                    label = { Text("커뮤니티") },
                    icon = { Text("💬") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (tab) {
                Tab.HOME -> HomeScreen()
                Tab.COMMUNITY -> CommunityHost(repo = repo)
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val mode by AppPrefs.limitModeFlow(context).collectAsState(initial = AppPrefs.LimitMode.COUNT)

    val count by AppPrefs.countFlow(context).collectAsState(initial = 0)
    val limitCount by AppPrefs.limitCountFlow(context).collectAsState(initial = 5)

    val timeUsedMs by AppPrefs.timeUsedMsFlow(context).collectAsState(initial = 0L)
    val limitTimeMin by AppPrefs.limitTimeMinFlow(context).collectAsState(initial = 15)

    var sliderCount by remember { mutableStateOf(limitCount.toFloat()) }
    LaunchedEffect(limitCount) { sliderCount = limitCount.toFloat() }

    var sliderTime by remember { mutableStateOf(limitTimeMin.toFloat()) }
    LaunchedEffect(limitTimeMin) { sliderTime = limitTimeMin.toFloat() }

    // ✅ 접속 보상 트리거(날짜 바뀐 첫 실행 때 rewardMsg 생성됨)
    LaunchedEffect(Unit) { scope.launch { AppPrefs.initTodayIfNeeded(context) } }

    val countProgress = (count.toFloat() / limitCount.coerceAtLeast(1)).coerceIn(0f, 1f)
    val timeLimitMs = (limitTimeMin.coerceAtLeast(1) * 60_000L)
    val timeProgress = (timeUsedMs.toFloat() / timeLimitMs.toFloat()).coerceIn(0f, 1f)

    val nick by AppPrefs.nicknameFlow(context).collectAsState(initial = "익명")
    val title by AppPrefs.titleFlow(context).collectAsState(initial = "")
    val streak by AppPrefs.streakFlow(context).collectAsState(initial = 0)
    val best by AppPrefs.bestStreakFlow(context).collectAsState(initial = 0)
    val points by AppPrefs.pointsFlow(context).collectAsState(initial = 0)
    val rewardMsg by AppPrefs.lastRewardMsgFlow(context).collectAsState(initial = "")

    // ✅ 스낵바로 “오늘의 접속 보상” 1번만 보여주기
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(rewardMsg) {
        if (rewardMsg.isNotBlank()) {
            snackbarHostState.showSnackbar(rewardMsg)
            AppPrefs.clearLastRewardMsg(context)
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("DopamineCut") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { inner ->
        Column(
            modifier = Modifier
                .padding(inner)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // ✅ 보상/프로필 카드(앱 접속 보상 확인용)
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("프로필 / 보상", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                    val shownNick = AppPrefs.decorateNickname(nick, title)
                    Text("닉네임: $shownNick")
                    Text("포인트: $points P")
                    Text("연속 접속: ${streak}일  ·  최고: ${best}일")

                    if (title.isNotBlank()) {
                        AssistChip(
                            onClick = {},
                            label = { Text("칭호: $title") }
                        )
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("오늘 현황", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("현재 적용: " + if (mode == AppPrefs.LimitMode.COUNT) "영상 개수 제한" else "시간 제한")

                    Text("영상: $count / $limitCount")
                    LinearProgressIndicator(progress = { countProgress }, modifier = Modifier.fillMaxWidth())

                    Text("시간: ${formatMs(timeUsedMs)} / ${limitTimeMin}분")
                    LinearProgressIndicator(progress = { timeProgress }, modifier = Modifier.fillMaxWidth())
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("제한 방식", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        val countSelected = mode == AppPrefs.LimitMode.COUNT
                        val timeSelected = mode == AppPrefs.LimitMode.TIME

                        if (countSelected) {
                            Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("영상 개수") }
                        } else {
                            OutlinedButton(
                                onClick = { scope.launch { AppPrefs.setLimitMode(context, AppPrefs.LimitMode.COUNT) } },
                                modifier = Modifier.weight(1f)
                            ) { Text("영상 개수") }
                        }

                        if (timeSelected) {
                            Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("시간") }
                        } else {
                            OutlinedButton(
                                onClick = { scope.launch { AppPrefs.setLimitMode(context, AppPrefs.LimitMode.TIME) } },
                                modifier = Modifier.weight(1f)
                            ) { Text("시간") }
                        }
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("제한 설정", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                    Text("영상 제한: ${sliderCount.toInt()}개")
                    Slider(
                        value = sliderCount,
                        onValueChange = { sliderCount = it },
                        valueRange = 1f..50f,
                        steps = 48,
                        enabled = (mode == AppPrefs.LimitMode.COUNT),
                        onValueChangeFinished = {
                            scope.launch { AppPrefs.setLimitCount(context, sliderCount.toInt()) }
                        }
                    )

                    Text("시간 제한: ${sliderTime.toInt()}분")
                    Slider(
                        value = sliderTime,
                        onValueChange = { sliderTime = it },
                        valueRange = 1f..240f,
                        steps = 238,
                        enabled = (mode == AppPrefs.LimitMode.TIME),
                        onValueChangeFinished = {
                            scope.launch { AppPrefs.setLimitTimeMin(context, sliderTime.toInt()) }
                        }
                    )
                }
            }

            OutlinedButton(
                onClick = { scope.launch { AppPrefs.resetToday(context) } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("오늘 기록 초기화(영상+시간)") }

            Button(
                onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("권한 설정(접근성) 열기") }

            OutlinedButton(
                onClick = {
                    val uri = android.net.Uri.fromParts("package", context.packageName, null)
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("앱 정보/권한 설정 열기") }

            Spacer(Modifier.height(8.dp))
        }
    }
}
