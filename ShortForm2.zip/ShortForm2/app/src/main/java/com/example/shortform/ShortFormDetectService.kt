package com.example.shortform

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class ShortFormDetectService : AccessibilityService() {

    // 시청 여부
    private var isWatching = false

    // 시작 시간
    private var startTime = 0L

    // 총 시청 시간
    private var totalWatchTime = 0L

    // 시청 횟수
    private var watchCount = 0

    // 감지할 앱 리스트
    private val shortFormApps = listOf(
        "com.google.android.youtube",     // 유튜브
        "com.instagram.android",          // 인스타
        "com.ss.android.ugc.trill"        // 틱톡
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return

        if (pkg in shortFormApps) {
            // 숏폼 시청 시작
            if (!isWatching) {
                isWatching = true
                startTime = System.currentTimeMillis()
                watchCount++

                Log.d("ShortForm", "📌 숏폼 시작! 총 ${watchCount}번째")
            }
        } else {
            // 숏폼에서 벗어남 → 시청 종료
            if (isWatching) {
                val duration = System.currentTimeMillis() - startTime
                totalWatchTime += duration
                isWatching = false

                Log.d("ShortForm", "📌 숏폼 종료! 이번 ${duration}ms, 총 ${totalWatchTime}ms")
            }
        }
    }

    override fun onInterrupt() {}
}
